import rclpy
from rclpy.node import Node
import time
from nav_msgs.msg import OccupancyGrid, Odometry, Path
from geometry_msgs.msg import PoseStamped
from visualization_msgs.msg import MarkerArray
from std_msgs.msg import String, Header

from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSHistoryPolicy, QoSReliabilityPolicy

class my_node(Node):
    def __init__(self):
        # Initialise subs, pubs, service calls, path object
        super().__init__('demo1_node')
        
        qos_policy = QoSProfile(durability=QoSDurabilityPolicy.TRANSIENT_LOCAL, reliability=QoSReliabilityPolicy.RELIABLE, history=QoSHistoryPolicy.KEEP_LAST, depth=1)
        self.get_logger().info('QOS Policy Set...')
        #Creating the start_explore publisher
        self.pub_start_explore = self.create_publisher(String, '/start_explore', 5) 
        self.get_logger().info('Start Explore Publisher Created...')
        #Creating the timer for the 8 second delay
        self.timer = self.create_timer(8, self.start_explore)
        self.get_logger().info('Timer Created...')   
        
        #Creating a subscriber to get the/map topic data
        self.sub_map_data = self.create_subscription(OccupancyGrid, '/map', self.callback_map, qos_policy)
        self.get_logger().info('Map Data Subscriber Created...')
        #Creating a publisher to publish map data to /ecte477/map topic
        self.pub_map_ecte = self.create_publisher(OccupancyGrid, '/ecte477/map', qos_policy)
        self.get_logger().info('Map Data Publisher Created...')

        #Creating a subscriber to get /stack_points data
        self.sub_stack_points = self.create_subscription(MarkerArray, '/stack_points', self.callback_stack_points, 5)
        self.get_logger().info(' Stack Points Subscriber Created...')

        #Creating a publisher for the /goal_pose topic
        self.pub_goal_pose = self.create_publisher(PoseStamped, '/goal_pose', qos_policy)
        self.get_logger().info('Goal Pose Publisher Created...')
        

        #Creating a subscriber to get the /odom topic data
        self.sub_odom = self.create_subscription(Odometry, '/odom', self.callback_odom, 5)
        self.get_logger().info('Odom Subscriber Created...')
        #Creating a publishers for the /ecte477/e_path and /ecte477/r_path topics
        self.pub_path = self.create_publisher(Path, '/ecte477/path', 5)
        self.get_logger().info('Path Publishers Created...')
        #Initializing variable for path recording
        self.path = Path()
        self.path.header.frame_id = 'odom'
        self.get_logger().info('Path Variable Created 1...')
        
        self.is_exploring = True 

             
    
    def start_explore(self):
        msg = String()
        msg.data = 'start'
        for _ in range(5):
            self.pub_start_explore.publish(msg)
            pass
        
        self.get_logger().info('Starting Exploration...')
        self.timer.cancel()

    def callback_map(self, data):
        self.get_logger().info('Map Data Published...')
        self.pub_map_ecte.publish(data)   
        
        
    def callback_odom(self, data):
        pose_stamped = PoseStamped()
        pose_stamped.header = data.header
        pose_stamped.pose = data.pose.pose
        self.path.poses.append(pose_stamped)
        self.pub_path.publish(self.path)

        # if self.is_exploring:            
        #     self.path.poses.append(pose_stamped)
        #     self.pub_path.publish(self.path)
            
        # else:
        #     #Have to write a code to stop path publishing when return to home poition              
        #     self.get_logger().info('No Path is Publishing...')               
       
        
    def callback_stack_points(self, stack_points):
        if len(stack_points.markers) == 0:
            self.get_logger().info('Exploration Completed!')
            self.is_exploring = False     
            

       
      
	
# Main function
def main(args=None):

    rclpy.init(args=args)
    print("Node is running...")

    mn = my_node()

    rclpy.spin(mn)

    mn.destroy_node()

    rclpy.shutdown()

if __name__ == '__main__':
    main()