import rclpy, message_filters, cv2
from rclpy.node import Node
import numpy as np
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
from cv_bridge import CvBridge
import time

class LineFollower(Node):
    def __init__(self):
        super().__init__('line_follower')
        self.get_logger().info('Line Follower Node Initialized')

        # Defining topics for the color and depth images
        color_image_topic = "/intel_realsense_r200_depth/image_raw"
        depth_image_topic = "/intel_realsense_r200_depth/depth/image_raw"

        #Creating Message Filters for synchronizing the color and depth images
        color_msg_filter = message_filters.Subscriber(self, Image, color_image_topic)
        depth_msg_filter = message_filters.Subscriber(self, Image, depth_image_topic)

        #Using approximate time synchronizer to synchronize the color and depth images
        self.camera_sync = message_filters.ApproximateTimeSynchronizer([color_msg_filter, depth_msg_filter], 10, 0.1)
        self.camera_sync.registerCallback(self.callback_camera)

        # Creating Publisher
        self.pub_move = self.create_publisher(Twist, '/cmd_vel', 1)

        #Initializing the CVBridge to Convert ROS Images to OpenCV Images
        self.bridge = CvBridge()

        # Variables for stopping at stop sign
        self.stop_sign_detected = False
        self.stop_time = None
        self.beacon_passed = False

        # Variable to Hold the current image for displaying
        self.image = None

        #Main loop to display image
        while rclpy.ok():
            if np.any(self.image):
                cv2.imshow('Image', self.image)
                cv2.waitKey(30)
            rclpy.spin_once(self, timeout_sec=1.0)

    def callback_camera(self, color_msg, depth_msg):
        self.get_logger().info('Processing Camera Callback')

        #Converting ROS image messages to OpenCV images
        color_image = self.bridge.imgmsg_to_cv2(color_msg, desired_encoding="bgr8")
        depth_image = self.bridge.imgmsg_to_cv2(depth_msg, desired_encoding="passthrough")

        # Processing Image to Filter Colors
        hsv = cv2.cvtColor(color_image, cv2.COLOR_BGR2HSV)
        lower_yellow = (25, 200, 100)
        upper_yellow = (35, 255, 255)
        lower_red = (0, 200, 100)
        upper_red = (5, 255, 255)
        lower_blue = (115, 200, 100)
        upper_blue = (125, 255, 255)

        mask_yellow = cv2.inRange(hsv, lower_yellow, upper_yellow)
        mask_yellow = cv2.erode(mask_yellow, None, iterations=2)
        mask_yellow = cv2.dilate(mask_yellow, None, iterations=2)

        mask_red = cv2.inRange(hsv, lower_red, upper_red)
        mask_red = cv2.erode(mask_red, None, iterations=2)
        mask_red = cv2.dilate(mask_red, None, iterations=2)

        mask_blue = cv2.inRange(hsv, lower_blue, upper_blue)
        mask_blue = cv2.erode(mask_blue, None, iterations=2)
        mask_blue = cv2.dilate(mask_blue, None, iterations=2)

        #Focus on the lower part of the image for lane detection
        h, w, d = color_image.shape
        search_top = 9 * h // 10
        search_bot = search_top + 50

        #Setting unwanted pixels to zero
        mask_yellow[0:search_top][:] = 0
        mask_yellow[search_bot:h][:] = 0
        mask_red[0:search_top][:] = 0
        mask_red[search_bot:h][:] = 0

        # Finding the Centroids of the Masks
        M_yellow = cv2.moments(mask_yellow)
        M_red = cv2.moments(mask_red)
        M_blue = cv2.moments(mask_blue)

        colors_found = {'RED': False, 'YELLOW': False} #Keep track of colors within the frame
        colors_location = {'RED': 0, 'YELLOW': 0} #Keep track of lane location based on the colors

        if M_yellow['m00'] > 0: #Checking if yellow is detected in the image using Zeroth Order Moment
            #m10 is the first order moment in x direction use to calculate centroid - sum of all x coordinates within the yellow mask / sum of pixel intesities within the mask
            cx_yellow = int(M_yellow['m10'] / M_yellow['m00']) 
            colors_found['YELLOW'] = True
            colors_location['YELLOW'] = cx_yellow
            cv2.circle(color_image, (cx_yellow, int(search_top)), 10, (0, 255, 255), -1)

        if M_red['m00'] > 0:
            cx_red = int(M_red['m10'] / M_red['m00'])
            colors_found['RED'] = True
            colors_location['RED'] = cx_red
            cv2.circle(color_image, (cx_red, int(search_top)), 10, (0, 0, 255), -1)

        if M_blue['m00'] > 0:
            cx_blue = int(M_blue['m10'] / M_blue['m00'])
            cy_blue = int(M_blue['m01'] / M_blue['m00'])
            beacon_depth = depth_image[cy_blue, cx_blue]
            if not self.stop_sign_detected and beacon_depth < 1.0 and not self.beacon_passed:  # Threshold for stopping
                self.stop_sign_detected = True
                self.stop_time = time.time()
                self.beacon_passed = True
            cv2.circle(color_image, (cx_blue, cy_blue), 10, (255, 0, 0), -1)
        else:
            self.beacon_passed = False

        self.image = color_image

        # Obstacle detection
        dh, dw = depth_image.shape
        center_depth = depth_image[dh // 2, dw // 2]

        # Decision Making Based on Detected Lines and Obstacles
        twist = Twist()

        if self.stop_sign_detected:
            if time.time() - self.stop_time < 3.0:  # Stop for 3 seconds
                twist.linear.x = 0.0
                twist.angular.z = 0.0
            else:
                self.stop_sign_detected = False
        elif center_depth < 0.5:  # Check for obstacles within 1 meter
            twist.linear.x = 0.0
            twist.angular.z = 0.0
        else:
            if not colors_found['RED'] and not colors_found['YELLOW']:
                twist.linear.x = 0.0
                twist.angular.z = 0.0
            elif not colors_found['RED']:
                twist.linear.x = 0.1
                twist.angular.z = -0.2
            elif not colors_found['YELLOW']:
                twist.linear.x = 0.2
                twist.angular.z = 0.1
            else:
                mid_point = (colors_location['RED'] + colors_location['YELLOW']) // 2
                err = mid_point - w // 2
                twist.linear.x = 0.2

                #PD Controller
                

                twist.angular.z = -float(err) / 950

        self.pub_move.publish(twist)

def main(args=None):
    rclpy.init(args=args)
    node = LineFollower()
    rclpy.spin(node)
    rclpy.shutdown()

if __name__ == '__main__':
    main()