#!/usr/bin/env python3
# Simple Action Server

import time
import rclpy
from rclpy.node import Node
from rclpy.action import ActionServer
from ecte_messages.action import ActRandNum
from random import randint

# Define a class for the simple action server, inheriting from Node
class SimpActionServer(Node):

    def __init__(self):
        # Initialize the node with the name 'action_server'
        super().__init__('action_server')
        
        # Create an ActionServer with the specified type, name, and callback
        self.act_srv = ActionServer(
            self,
            ActRandNum,
            'gen_rand_numbers',
            self.go_rand
        )

    # Callback function that gets called when a new goal is received
    def go_rand(self, goal):
        goal.succeed()  # Mark the goal as succeeded
        print("The random integer action server has been called!")
        
        feedback_msg = ActRandNum.Feedback()  # Create a feedback message object
        final_result = ActRandNum.Result()  # Create a result message object

        # Generate intermediate random numbers and provide feedback
        for i in range(1, goal.request.total):
            feedback_msg.intermediates = randint(goal.request.slimit, goal.request.flimit)
            goal.publish_feedback(feedback_msg)  # Publish the feedback
            time.sleep(2)  # Sleep for 2 seconds to simulate processing time

        # Generate the final random number and set it in the result
        print("The sequence of random numbers has been completed.")
        final_result.final = randint(goal.request.slimit, goal.request.flimit)
        
        # Return the final result
        return final_result

def main(args=None):
    rclpy.init(args=args)  # Initialize the ROS client library
    new_action_server = SimpActionServer()  # Create an instance of the action server
    rclpy.spin(new_action_server)  # Spin the node to keep it running

# Entry point for the script
if __name__ == '__main__':
    main()
