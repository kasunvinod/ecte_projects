import rclpy
from rclpy.node import Node
from ecte_messages.srv import SrvRandNum
from random import randint

class ServiceServer(Node):
    def __init__(self):
        super().__init__('service_server')
        
        self.srv = self.create_service(SrvRandNum, 'rand_num_srv', self.handle_request)


    def handle_request(self, request, response):
        self.get_logger().info('Incoming request: {0} {1}'.format(request.a, request.b))
        response.result = randint(request.a, request.b)

        return response    

def main(args=None):
    rclpy.init(args=args)
    node = ServiceServer()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()   

if __name__ == '__main__':
    main()