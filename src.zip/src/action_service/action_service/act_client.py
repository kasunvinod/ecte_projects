import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from ecte_messages.action import ActRandNum

# Define a class for the simple action client, inheriting from Node
class SimpActionClient(Node):

    def __init__(self):
        # Initialize the node with the name 'action_client'
        super().__init__('action_client')
        
        # Create an ActionClient with the specified type and name
        self.act_client = ActionClient(self, ActRandNum, 'gen_rand_numbers')

    # Method to send a goal to the action server
    def send_goal(self):
        # Create a goal message
        goal_msg = ActRandNum.Goal()

        # Get goal parameters from the user
        goal_msg.slimit = int(input("Please enter a lower limit for your random numbers! "))
        goal_msg.flimit = int(input("Please enter an upper limit for your random numbers! "))
        goal_msg.total = int(input("Please enter the total number of random integers you would like to generate! "))

        # Wait for the action server to be available
        self.act_client.wait_for_server()

        # Send the goal to the server asynchronously
        send_goal_to_server = self.act_client.send_goal_async(goal_msg, feedback_callback=self.rand_feedback)

        # Add a callback for when the goal response is received
        send_goal_to_server.add_done_callback(self.goal_response_callback)

    # Callback function to handle feedback from the action server
    def rand_feedback(self, feedback_msg):
        print("Your random number is:", feedback_msg.feedback.intermediates)

    # Callback function to handle the goal response
    def goal_response_callback(self, future):
        goal_handle = future.result()
        # Get the result asynchronously
        get_result = goal_handle.get_result_async()
        # Add a callback for when the final result is received
        get_result.add_done_callback(self.final_result_callback)

    # Callback function to handle the final result
    def final_result_callback(self, result_future):
        final_result = result_future.result().result
        print("The final random number is:", final_result.final)
        rclpy.shutdown()

# Main function to initialize and spin the action client
def main(args=None):
    rclpy.init(args=args)  # Initialize the ROS client library
    new_action_client = SimpActionClient()  # Create an instance of the action client
    new_action_client.send_goal()  # Send the goal to the action server
    rclpy.spin(new_action_client)  # Spin the node to keep it running

# Entry point for the script
if __name__ == '__main__':
    main()
