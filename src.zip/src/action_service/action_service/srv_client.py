import rclpy
from rclpy.node import Node
from ecte_messages.srv import SrvRandNum

class ServiceClient(Node):
    def __init__(self):
        super().__init__('service_client')
        self.client = self.create_client(SrvRandNum, 'rand_num_srv')
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Service not available, waiting for server....')
        self.request = SrvRandNum.Request()

    def send_request(self):
        self.request.a = int(input('Enter the lower limit: '))
        self.request.b = int(input('Enter the upper limit: '))
        self.result = self.client.call_async(self.request)
        rclpy.spin_until_future_complete(self, self.result)
        return self.result.result()


def main(args=None):
    rclpy.init(args=args)
    
    new_client = ServiceClient()
    response = new_client.send_request()
    print('Response: {0}'.format(response.result))

    new_client.destroy_node()
    rclpy.shutdown()
    

if __name__ == '__main__':
    main()        