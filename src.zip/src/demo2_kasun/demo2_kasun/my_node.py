import rclpy
from rclpy.node import Node
import cv2
import imutils
import numpy as np
from sensor_msgs.msg import Image, CameraInfo
from nav_msgs.msg import Odometry, Path, OccupancyGrid
from cv_bridge import CvBridge
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, QoSHistoryPolicy
from . import transformations as trans
from geometry_msgs.msg import Point, Quaternion, Pose, Vector3, PoseStamped
from std_msgs.msg import ColorRGBA
from visualization_msgs.msg import Marker, MarkerArray
from ecte_messages.msg import Beacon

class ImageProcessingNode(Node):
    def __init__(self):
        super().__init__('image_processing_node')
        self.get_logger().info('Image Processing Node Started')

        #Setting Up Variables
        self.bridge = CvBridge()
        self.colour_frame = None
        self.depth_frame = None
        self.mask = None
        self.num_colour_images = 0
        self.num_depth_images = 0
        self.K = None
        self.tf_cam_to_world = None
        
        self.declare_parameters(
            namespace='',
            parameters=[
                ('beacons.id', rclpy.Parameter.Type.INTEGER_ARRAY),
                ('beacons.top', rclpy.Parameter.Type.STRING_ARRAY),
                ('beacons.bottom', rclpy.Parameter.Type.STRING_ARRAY),
                ('beacons.description', rclpy.Parameter.Type.STRING_ARRAY),
                ('colours.name', rclpy.Parameter.Type.STRING_ARRAY),
                ('hsv.red_lb', rclpy.Parameter.Type.INTEGER_ARRAY),
                ('hsv.red_ub', rclpy.Parameter.Type.INTEGER_ARRAY),
                ('hsv.yellow_lb', rclpy.Parameter.Type.INTEGER_ARRAY),
                ('hsv.yellow_ub', rclpy.Parameter.Type.INTEGER_ARRAY),
                ('hsv.green_lb', rclpy.Parameter.Type.INTEGER_ARRAY),
                ('hsv.green_ub', rclpy.Parameter.Type.INTEGER_ARRAY),
                ('hsv.blue_lb', rclpy.Parameter.Type.INTEGER_ARRAY),
                ('hsv.blue_ub', rclpy.Parameter.Type.INTEGER_ARRAY)
            ]
        ) 
                        
        self.load_parameters()      

        self.beacon_array = MarkerArray()
        self.detected_beacons = {}        

        #Defining QoS Policy
        qos_policy = QoSProfile(durability=QoSDurabilityPolicy.VOLATILE, reliability=QoSReliabilityPolicy.BEST_EFFORT, history=QoSHistoryPolicy.KEEP_LAST, depth=5)

        #Setting up Subscribers and Publishers
        self.sub_colour = self.create_subscription(Image, '/intel_realsense_r200_depth/image_raw', self.callback_colour, qos_policy)
        self.sub_depth = self.create_subscription(Image, '/intel_realsense_r200_depth/depth/image_raw', self.callback_depth, qos_policy)
        self.sub_cam_info = self.create_subscription(CameraInfo, '/intel_realsense_r200_depth/camera_info', self.callback_cam_info, qos_policy)
        self.sub_odom = self.create_subscription(Odometry, '/odom', self.callback_odom, 5)       

        self.pub_markers = self.create_publisher(MarkerArray, '/ecte477/markers', 5)
        self.pub_beacons = self.create_publisher(Beacon, '/ecte477/beacons', 5)


        #Including the Subscribers and Publishers from Demo1
        #Creating a subscriber to get the/map topic data
        self.sub_map_data = self.create_subscription(OccupancyGrid, '/map', self.callback_map, qos_policy)
        self.get_logger().info('Map Data Subscriber Created...')
        #Creating a publisher to publish map data to /ecte477/map topic
        self.pub_map_ecte = self.create_publisher(OccupancyGrid, '/ecte477/map', qos_policy)
        self.get_logger().info('Map Data Publisher Created...')
        #Creating a subscriber to get the /odom topic data
        self.sub_odom = self.create_subscription(Odometry, '/odom', self.callback_odom, 5)
        self.get_logger().info('Odom Subscriber Created...')
        #Creating a publishers for the /ecte477/e_path and /ecte477/r_path topics
        self.pub_path = self.create_publisher(Path, '/ecte477/path', 5)
        self.get_logger().info('Path Publishers Created...')
        #Initializing variables for path recording
        self.path = Path()
        self.path.header.frame_id = 'odom'
        self.get_logger().info('Path Variable Created 1...')
        
        self.is_exploring = True


        while rclpy.ok():
            self.loop()
            rclpy.spin_once(self, timeout_sec=1.0)    

    def callback_map(self, data):
        self.get_logger().info('Map Data Published...')
        self.pub_map_ecte.publish(data)         
    
    
    def load_parameters(self):
        beacon_ids = self.get_parameter('beacons.id').get_parameter_value().integer_array_value
        beacon_tops = self.get_parameter('beacons.top').get_parameter_value().string_array_value
        beacon_bottoms = self.get_parameter('beacons.bottom').get_parameter_value().string_array_value
        beacon_descriptions = self.get_parameter('beacons.description').get_parameter_value().string_array_value
        
        #Creating Beacon Type Dictionary
        self.beacon_types = {}

        for i in range(len(beacon_ids)):
            self.beacon_types[(beacon_tops[i], beacon_bottoms[i])] = (beacon_ids[i], beacon_descriptions[i])

        #Creating Beacon Colour Dictionary
        self.colour_dic = {}

        for i in range(len(beacon_ids)):
            self.colour_dic[beacon_ids[i]] = (beacon_tops[i], beacon_bottoms[i])

        #Creating Colour Names Array for Terminal Updates
        self.colour_names = self.get_parameter('colours.name').get_parameter_value().string_array_value

        #Creating HSV Ranges Array
        hsv_red_lb = self.get_parameter('hsv.red_lb').get_parameter_value().integer_array_value
        hsv_red_ub = self.get_parameter('hsv.red_ub').get_parameter_value().integer_array_value
        hsv_yellow_lb = self.get_parameter('hsv.yellow_lb').get_parameter_value().integer_array_value
        hsv_yellow_ub = self.get_parameter('hsv.yellow_ub').get_parameter_value().integer_array_value
        hsv_green_lb = self.get_parameter('hsv.green_lb').get_parameter_value().integer_array_value
        hsv_green_ub = self.get_parameter('hsv.green_ub').get_parameter_value().integer_array_value
        hsv_blue_lb = self.get_parameter('hsv.blue_lb').get_parameter_value().integer_array_value
        hsv_blue_ub = self.get_parameter('hsv.blue_ub').get_parameter_value().integer_array_value

        self.colour_range = [
            ((hsv_red_lb[0], hsv_red_lb[1], hsv_red_lb[2]), (hsv_red_ub[0], hsv_red_ub[1], hsv_red_ub[2])),
            ((hsv_yellow_lb[0], hsv_yellow_lb[1], hsv_yellow_lb[2]), (hsv_yellow_ub[0], hsv_yellow_ub[1], hsv_yellow_ub[2])),
            ((hsv_green_lb[0], hsv_green_lb[1], hsv_green_lb[2]), (hsv_green_ub[0], hsv_green_ub[1], hsv_green_ub[2])),
            ((hsv_blue_lb[0], hsv_blue_lb[1], hsv_blue_lb[2]), (hsv_blue_ub[0], hsv_blue_ub[1], hsv_blue_ub[2]))
        ]        
        
        self.get_logger().info(f"Parameters Loaded Successfully...")
        
    
    def callback_colour(self, colour_image):
        #Variable Declaration
        detected_colors = []

        #self.get_logger().info('[Image Processing] Colour Image Received')
        self.colour_frame = self.bridge.imgmsg_to_cv2(colour_image, 'bgr8')
        blurred = cv2.GaussianBlur(self.colour_frame, (11, 11), 0)
        hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

        for i, (colour_lower, colour_upper) in enumerate(self.colour_range):           
            self.mask = cv2.inRange(hsv, colour_lower, colour_upper)
            self.mask = cv2.erode(self.mask, None, iterations=2)
            self.mask = cv2.dilate(self.mask, None, iterations=2)

            contours = cv2.findContours(self.mask.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            contours = imutils.grab_contours(contours)

            if len(contours) > 0:                
                largest_contour = max(contours, key=cv2.contourArea)
                x, y, w, h = cv2.boundingRect(largest_contour)
                #colour_frame = cv2.rectangle(self.colour_frame, (x, y), (x+w, y+h), (0, 0, 255), 2)
                #self.get_logger().info(f"Color {i+1} detected")

                colour_name = self.colour_names[i]
                detected_colors.append((colour_name, x, y))                

        if len(detected_colors) == 2:
            colour1, x1, y1 = detected_colors[0]
            colour2, x2, y2 = detected_colors[1]

            if y1 < y2:
                top_colour, bottom_colour = colour1, colour2
                beacon_x = x1
                beacon_y = y1
                
            else:
                top_colour, bottom_colour = colour2, colour1
                beacon_x = x2
                beacon_y = y2
                
            #self.get_logger().info(f"Top Colour: {top_colour}, Bottom Colour: {bottom_colour}")

            self.beacon_id, beacon_type = self.beacon_types.get((top_colour, bottom_colour), (0, 'Unknown Beacon Type'))

            self.get_logger().info(f"Beacon Type Detected: {beacon_type}")
            colour_frame = cv2.rectangle(self.colour_frame, (beacon_x, beacon_y), (beacon_x+w, beacon_y+2*h), (255, 0, 0), 2)
            colour_frame = cv2.putText(colour_frame, beacon_type, (beacon_x, beacon_y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 2)

            if np.any(self.K) and np.any(self.tf_cam_to_world) and np.any(self.depth_frame):
                depth = self.depth_frame[y + h//2, x + w//2] + 0.075 # Get depth at the center of the bounding box
                # self.get_logger().info(f"y: {beacon_y}, x: {beacon_x}")
                # self.get_logger().info(f"y: {beacon_y + h//2}, x: {beacon_x + w//2}")
                p_h = np.array([[beacon_x + w//2], [beacon_y + h//2], [1]])  # homogeneous vector
                p3d = depth * np.matmul(np.linalg.inv(self.K), p_h)
                p3d_h = np.array([[p3d[2][0]], [-p3d[0][0]], [-p3d[1][0]], [1]])  # Note
                p3d_w_h = np.matmul(self.tf_cam_to_world, p3d_h)
                p3d_w = np.array([[p3d_w_h[0][0]/p3d_w_h[3][0]], [p3d_w_h[1][0]/p3d_w_h[3][0]], [p3d_w_h[2][0]/p3d_w_h[3][0]]])
                #self.get_logger().info(f"3D World Coordinates: {p3d_w}")
                
                if abs(depth) < 1.5:
                    #Publishing Beacon Point to RViz
                    self.get_logger().info(f"Depth: {depth}")
                    self.publish_beacon_marker(p3d_w, self.beacon_id)

        elif len(detected_colors) > 2:
            self.get_logger().info('[Image Processing] Multiple Beacons Detected')
            

    def callback_depth(self, depth_image):
        #self.get_logger().info('[Image Processing] Depth Image Received')
        self.depth_frame = self.bridge.imgmsg_to_cv2(depth_image, desired_encoding='passthrough')

    def loop(self):
        if np.any(self.colour_frame) and np.any(self.depth_frame):
            cv2.imshow('Colour Image', self.colour_frame)
            #cv2.imshow('Depth Image', self.depth_frame)
            #cv2.imshow('Masked Image', self.mask)
            response = cv2.waitKey(80)
            if response == ord('c'):
                self.get_logger().info('[Image Processing] Colour Image Saved')
                cv2.imwrite('colour_{}.png'.format(self.num_colour_images), self.colour_frame)
                self.num_colour_images += 1

            if response == ord('d'):
                self.get_logger().info('[Image Processing] Depth Image Saved')
                cv2.imwrite('depth_{}.png'.format(self.num_depth_images), self.depth_frame)
                self.num_depth_images += 1

    def callback_cam_info(self, cam_info):
        #self.get_logger().info('[Image Processing] Camera Info Received')
        self.K = np.array(cam_info.k).reshape(3, 3) 


    def callback_odom(self, odom):
        #self.get_logger().info('[Image Processing] Odometry Received')
        self.tf_cam_to_world = trans.msg_to_se3(odom.pose.pose)
        pose_stamped = PoseStamped()
        pose_stamped.header = odom.header
        pose_stamped.pose = odom.pose.pose
        self.path.poses.append(pose_stamped)
        self.pub_path.publish(self.path)

    def publish_beacon_marker(self, position, beacon_id):
        if self.beacon_id not in self.detected_beacons:
            #Publishing Marker
            marker = Marker()
            marker.id = beacon_id  # Use beacon type as the unique ID
            marker.header.frame_id = 'map'
            marker.header.stamp = self.get_clock().now().to_msg()
            
            mk_point = Point()
            mk_point.x, mk_point.y, mk_point.z = position[0][0], position[1][0], 0.0
            
            mk_quat = Quaternion()
            mk_quat.x, mk_quat.y, mk_quat.z, mk_quat.w = 0.0, 1.0, 0.0, 1.0
            
            mk_pose = Pose()
            mk_pose.position, mk_pose.orientation = mk_point, mk_quat
            
            marker.pose = mk_pose
            
            mk_scale = Vector3()
            mk_scale.x, mk_scale.y, mk_scale.z = 0.1, 0.1, 0.1
            marker.scale = mk_scale
            
            mk_colour = ColorRGBA()
            mk_colour.r, mk_colour.g, mk_colour.b, mk_colour.a = 0.0, 1.0, 0.0, 1.0
            marker.color = mk_colour
            
            self.beacon_array.markers.append(marker)
            self.pub_markers.publish(self.beacon_array)

            self.detected_beacons[beacon_id] = position

            self.get_logger().info(f"Marker published for beacon {beacon_id}")

            #Publishing Beacon Message
            beacon_msg = Beacon()            
            beacon_msg.seq = beacon_id            
            beacon_msg.header.stamp = self.get_clock().now().to_msg()            
            beacon_msg.header.frame_id = 'map'            
            beacon_msg.top, beacon_msg.bottom = self.colour_dic.get(2, ('Unknown Color', 'Unknown Color'))            
            beacon_msg.position = mk_point            

            self.pub_beacons.publish(beacon_msg)           

        else:
            self.get_logger().info(f"Beacon {beacon_id} already detected. Skipping marker publication.")
        

def main(args=None):
    rclpy.init(args=args)
    new_ipn = ImageProcessingNode()
    rclpy.spin(new_ipn)

if __name__ == '__main__':
    main()